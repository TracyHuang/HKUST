CS418 MP2 Flight Simulator
Huang Tianwei
NETID: thuang23
Taking course for 3 credits.

Compile environment: Win 7 + Visual Studio 2010

Instruction:
w, s for pitch
a, d for roll

video link: http://youtu.be/IxCaVdu67mU
