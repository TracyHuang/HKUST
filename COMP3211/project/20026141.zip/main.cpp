#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <queue>
#include <stdlib.h>
#include <sstream>

using namespace std;

	int numBidder;
	bool existRandom;
	int numAuction;
	bool resultOpen;
	bool bidInterval;

	double* possibleBid; // double array used to store all possible bids
	int bidSize;         // number of possible bids
	bool newGame;        // if the current round is the first round
	double* neBid;
	int neSize;

void clearAll(string filename) {
	ofstream ofs;
	ofs.open("test.txt", std::ofstream::out | std::ofstream::trunc);
	ofs.close();
	return;
}

void parseString(string bid) {
	//out << bid << endl;
	//int a;
	//cin >> a;
	size_t length = bid.length();
	queue<double> temp;
	size_t start = 1;   //the first character is {
	size_t found = 0;
	while (found = bid.find_first_of(",", start)) {
		if (found == string::npos) {
			double value = atof(bid.substr(start).c_str());     // length - 1 is the index of the last character
			temp.push(value);
			break;
		}
		else {
			double value = atof(bid.substr(start, found - start).c_str());
			temp.push(value);
			start = found + 1;
		}
	}

	//put all possible bids into bid array
	int size = temp.size();
	bidSize = size;
	possibleBid = new double[size];
	int i = 0;
	while(temp.size()) {
		possibleBid[i] = temp.front();
		temp.pop();
		i ++;
	}
	return;
}


void setup() {                    // read setup.txt
	ifstream fin("setup.txt");
	fin >> numBidder;
	//cout << "numBidder =" << numBidder << endl;
	fin >> existRandom;
	//cout << "exist = " << existRandom << endl;
	fin >> numAuction;
	//cout << "numAction" << numAuction << endl;
	fin >> resultOpen;
	//cout << "open =" << resultOpen << endl;
	string line = "";
	getline(fin, line);
	while (line.length() == 0) {
		getline(fin, line);
	}
	//	cout << "line" << line << endl;
	bidInterval = false;
	if (line[0] == '[' && line[line.length() - 1] == ']') {
		bidInterval = true;
		return;
	}
	parseString(line);
	return;
}

void getNE() {

	neSize = 0;
	if (bidSize == 2) {   // deal with prisoner's dilemma
		if ((1.0 - possibleBid[0]) / 2 >= (1.0 - possibleBid[1])) {
			neBid = new double[2];
			neBid[0] = possibleBid[0];
			neBid[1] = possibleBid[1];
			neSize = 2;
		}
		else {
			neBid = new double[1];
			neBid[0] = possibleBid[0];
			neSize = 1;
		}
		return;
	}

	queue<double> q;
	for (int i = 0; i < bidSize - 1; i ++ ) {
		if (((1 - possibleBid[i]) / numBidder ) >= (1 - possibleBid[i+1])) {
			q.push(possibleBid[i]);
			neSize ++;
		}
	}
	q.push(possibleBid[bidSize - 1]);
	neSize ++;

	neBid = new double[neSize];
	for (int i = 0; i < neSize; i ++) {
		neBid[i] = q.front();
		q.pop();
	}
	return;
}
bool is_empty(ifstream& pFile)
{
    return pFile.peek() == ifstream::traits_type::eof();
}

void testNewGame() {                  //test if a new game
	ifstream file("result.txt");
	if(is_empty(file))
	{
	  newGame = true;
	  return;
	}
	newGame = false;
	return;
}

void storeBid(double value, int round, int winnerSameCount) {  
	string historyFile = "history_20026141.txt";
	clearAll(historyFile);
	ofstream file ("history_20026141.txt");

	  file << round << '\n';
	  file << value << '\n';
	  file << winnerSameCount << '\n';
	  file.close();
}


/*
	ofstream outfile ("test.txt");
	outfile.close();
	string line;
	ifstream myfile ("test.txt");
	while (getline(myfile, line)) {
	double a = atof(line.c_str());

*/
void readHistory(int& round, double& lastBid, int& winnerSameCount) {
	string line;
	ifstream historyFile ("history_20026141.txt");
	getline(historyFile, line);
	string round_str = line;
	round = atoi(line.c_str());
	getline(historyFile, line);
	string lastbid_str = line;
	lastBid = atof(line.c_str());
	getline(historyFile, line);
	string wsc_str = line;
	winnerSameCount = atoi(line.c_str());
	historyFile.close();
}

int main() {
newGame = false;
//string historyFile = "history_20026141.txt";
setup();
/*
for (int i = 0; i < bidSize; i ++) {
	cout << possibleBid[i] << endl;
}
*/
testNewGame();
double result;
if (newGame) {
	ifstream ifile("history_20026141.txt");
	if (ifile) {
	  clearAll("history_20026141.txt");
	}
	else {
		//create history file
		ofstream outfile("history_20026141.txt");
		outfile.close();
	}
	ifile.close();

	if (bidInterval) {    // continuous possible bids
		if (existRandom) {
			result = 0.6;
			storeBid(result, 1, 0);
			cout << result;
			return 0;
		}
		
		if (numBidder == 0) {          //unknown number of bidder
			result = (double) rand() / (RAND_MAX) ;      //generate random number between [0,1)
		}
		else {                         //known number of bidder
			double temp = numBidder;
			result = (temp - 1) / temp;
		}
	}
	else {      //discrete possible bids

		if (numBidder == 0) {          //unknown number of bidder
			result = possibleBid[bidSize - 1];
		}
		else {                // known number of bidder
			// calculate NEs first
			getNE();
			if (neSize == 1) {
				result = possibleBid[bidSize - 1];
			}
			else {
				result = neBid[neSize - 2]; //the last but one NE
			}
		}
	}


	storeBid(result, 1, 0);
	cout << result;
	return 0;
}

// not new game
else {
int round;
double lastBid;
int winnerSameCount;
readHistory(round, lastBid, winnerSameCount);
//cout << "round = " << round << " lastbid = " << lastBid << " winnersamecount = " << winnerSameCount << endl;
 
ifstream resultFile ("result.txt");
double winnerBid = 0.0;
//string round_str = to_string(round);
ostringstream ostr;
ostr << round;
string round_str = ostr.str();


string target_str = string("round ") + round_str;
string line;
while ( getline (resultFile ,line) ) {
	if (line != target_str ) {
		continue;
	}
	else {
		getline (resultFile, line);
		if(line == "-") {
			break;
		}
		size_t index = line.find(',');
		string bid_str = line.substr(index + 1);
		winnerBid = atof(bid_str.c_str());
		break;
	}
}

//cout << "winnerBid" << winnerBid;

if(winnerBid == lastBid) {
winnerSameCount ++;
}
else {
winnerSameCount = 0;
}

//cout << "winnerSameCount = " << winnerSameCount << endl;
double result;

if (winnerSameCount >= 2) {
	if(bidInterval) {
	result = 0.0;
	}
	else {
	result = possibleBid[0];
	}

}

else {
	if (bidInterval) {
		result = 1 / (2 - winnerBid); 
	}
	else {
		if(numBidder != 0) {
			getNE();
			for (int i = 0; i < neSize; i ++) {             // note that the last one must be bigger than or equal to winnerBid
				if (neBid[i] >= winnerBid) {
					result = neBid[i];
					break;
				}
			}
		}
		else {
			for (int i = 0; i < bidSize; i ++) {
				if(possibleBid[i] >= winnerBid) {
					result = possibleBid[i];
					break;
				}
			}
		}
	}
}
storeBid(result, round + 1, winnerSameCount);
cout << result;
return 0;


}



}



